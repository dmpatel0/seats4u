module.exports = {
    // credentials to the DB are here. HIDDEN and not exposed outside
    config : {
    "host" : "calculatordbpreet.cqzvfpdekvum.us-east-2.rds.amazonaws.com",
    "user" : "calcAdminPreet",
    "password" : "calc:pass",
    "database" : "calc"
    }
    }
    