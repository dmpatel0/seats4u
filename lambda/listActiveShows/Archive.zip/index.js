const mysql = require('mysql');
const db_access = require('/opt/nodejs/db_access')

exports.handler = async (event) => {
  
  // get credentials from the db_access layer (loaded separately via AWS console)
  var pool = mysql.createPool({
      host: db_access.config.host,
      user: db_access.config.user,
      password: db_access.config.password,
      database: db_access.config.database
  });


  let listActiveShow = (venueName, isActive) => {
    return Promise((resolve, reject) => {
        pool.query("SELECT showName, showTime FROM Shows where venueName = ? AND isActive = ?"), [venueName, isActive], (error, rows) => {
            if(error){
                return reject(error);
            }
            return resolve(rows);
        }
    })
  }

  let response = undefined;

  try{
    let result = await listActiveShow(event.venueName, 1);
    response = {
        statusCode: 200,

        shows: result
    }
  }
  catch(error){
    response = {
        statusCode: 400,

        error: error
    }
  }

  pool.end();

  return response;


}